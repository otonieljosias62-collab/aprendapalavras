
FREE APP

Created by WebIntoApp.com on Monday 17th of August 2026 12:53:59 PM.

Release APK & App Bundle (AAB) ready to be submitted to Google Play Store 
and to any other APK / AAB store over the internet.

-------------------------------------
App ID:			1563971
App Key:		xzdxlmBAMZXrPsOyyCuVwViEAzliJmKv
App Name:		dashcards
App Version:	1.0
Package:		com.mycompany.dashcards
Mode:			Free App
-------------------------------------

Your free app is ready, you can now publish it to the 
google play store and to any apk app store on the internet.

-------------------------------------
Please note, your app is under a FREE mode, you can always 
convert it to your own dedicated and branded mobile app for 
Android and iOS with all the premium features at:

https://webintoapp.com/author/apps/1563971/edit?cmd=app-switcher

-------------------------------------
Here are some useful links:
-------------------------------------

You can edit your app at:
https://webintoapp.com/author/apps

Get installs statistics at:
https://webintoapp.com/author/stats?appid=1563971

The Author Area:
https://webintoapp.com/author/dashboard

-------------------------------------
WebIntoApp.com Team.
https://www.webintoapp.com
-------------------------------------
